<?php 

	// Gets all the comments made by a specific user.

?>