<?php 

	// Gets all the dislikes of a specific user

?>