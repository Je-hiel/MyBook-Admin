<?php 

	// Gets all the likes of a specific user

?>